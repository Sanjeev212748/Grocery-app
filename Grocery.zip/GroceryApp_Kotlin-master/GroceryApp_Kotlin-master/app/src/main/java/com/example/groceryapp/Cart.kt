package com.example.groceryapp

data class Cart(var name:String, var price:Int)