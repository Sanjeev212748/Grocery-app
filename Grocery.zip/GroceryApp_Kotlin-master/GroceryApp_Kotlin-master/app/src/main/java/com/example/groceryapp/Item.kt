package com.example.groceryapp

data class Item(var name:String, var price:Int, var imageId: Int)