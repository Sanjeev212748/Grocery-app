package com.example.groceryapp

data class Category(var imageId: Int, var category: String)